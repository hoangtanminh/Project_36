package com.example.demo;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        Database.init();

        FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/com/example/demo/login.fxml")
        );
        Scene scene = new Scene(loader.load(), 400, 350);
        stage.setTitle("Hệ thống Đấu Giá");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}