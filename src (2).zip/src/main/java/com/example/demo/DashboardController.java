package com.example.demo;

public class DashboardController {
    public void setUser(User user) {
    }
}
